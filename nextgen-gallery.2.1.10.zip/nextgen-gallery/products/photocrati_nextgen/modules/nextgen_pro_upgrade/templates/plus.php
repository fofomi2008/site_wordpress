<div id='nextgen_pro_upgrade_page' class='plus'>
    <h1><?php echo $headline; ?></h1>

    <hr/>

    <h2><?php echo $description; ?></h2>
    <h2>LEARN MORE:</h2>

    <a href='http://www.nextgen-gallery.com/nextgen-plus' target='_blank' class="button-primary" id="nextgen_pro_upgrade_first_link">
        NextGEN Plus (Displays Only)
    </a>

    <a href='http://www.nextgen-gallery.com/nextgen-pro' target='_blank' class="button-primary">
        NextGEN Pro (Displays + Ecommerce)
    </a>

</div>
